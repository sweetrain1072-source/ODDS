ODDS - 설치형 웹앱(PWA)
1) 이 폴더 전체를 https 호스팅(Netlify Drop 등)에 올려요.
2) 주소/ : 기기에 맞게 자동 이동, 주소/phone/ : 폰(세로), 주소/desktop/ : 컴퓨터(가로)
3) 설치: 안드로이드 Chrome 메뉴>앱 설치, 아이폰 Safari 공유>홈 화면에 추가, 컴퓨터 Chrome/Edge 주소창 설치 아이콘
저장은 각 기기 브라우저 안에 돼요.
